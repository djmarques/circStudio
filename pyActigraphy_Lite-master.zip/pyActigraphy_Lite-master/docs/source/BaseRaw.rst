=============
BaseRaw class
=============

.. currentmodule:: pyActigraphy.io.BaseRaw
.. autoclass:: pyActigraphy.io.BaseRaw
   :members:
