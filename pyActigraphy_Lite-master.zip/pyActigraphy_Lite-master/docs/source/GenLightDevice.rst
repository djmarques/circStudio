==========================
Generic Light Device class
==========================

.. contents:: Table of Contents
    :local:
    :depth: 2

.. currentmodule:: pyActigraphy.light.GenLightDevice
.. autoclass:: pyActigraphy.light.GenLightDevice

   .. rubric:: Attributes
   .. autosummary::
       :toctree: _autosummary/

       cct
       duv
       tilt
       triggered_by_user
