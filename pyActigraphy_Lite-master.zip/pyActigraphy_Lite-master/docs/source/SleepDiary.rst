=================
Sleep diary class
=================

.. contents:: Table of Contents
    :local:
    :depth: 2

.. currentmodule:: pyActigraphy.sleep.SleepDiary
.. autoclass:: pyActigraphy.sleep.SleepDiary

   .. rubric:: Summary statistics
   .. autosummary::
       :toctree: _autosummary/

       summary
       state_infos
       total_bed_time
       total_nap_time
       total_nowear_time
