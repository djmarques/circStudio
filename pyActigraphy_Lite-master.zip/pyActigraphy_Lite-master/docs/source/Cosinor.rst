=============
Cosinor class
=============

.. currentmodule:: pyActigraphy.analysis.Cosinor
.. autoclass:: pyActigraphy.analysis.Cosinor

    .. rubric:: Attributes
    .. autosummary::
        :toctree: _autosummary/

        fit_func
        fit_initial_params

    .. rubric:: Methods
    .. autosummary::
        :toctree: _autosummary/

        fit
        best_fit
        fit_reader
