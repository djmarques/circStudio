====================
ActivityReport class
====================

.. contents:: Table of Contents
    :local:
    :depth: 2

.. currentmodule:: pyActigraphy.reports.ActivityReport
.. autoclass:: pyActigraphy.reports.ActivityReport

   .. rubric:: Activity report
   .. autosummary::
       :toctree: _autosummary/

       cut_points
       labels
       results
       fit
       pretty_results
