===============
RawReader class
===============

.. currentmodule:: pyActigraphy.io
.. autoclass:: pyActigraphy.io.RawReader
   :members:
