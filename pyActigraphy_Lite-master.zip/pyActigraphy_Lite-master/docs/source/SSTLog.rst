=========================
Start/Stop time log class
=========================

.. contents:: Table of Contents
    :local:
    :depth: 2

.. currentmodule:: pyActigraphy.log.SSTLog
.. autoclass:: pyActigraphy.log.SSTLog

   .. autosummary::
       :toctree: _autosummary/

       summary
