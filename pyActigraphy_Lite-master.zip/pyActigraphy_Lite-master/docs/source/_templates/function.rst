{{ fullname }}
{{ underline }}

.. currentmodule:: {{ module }}

.. autofunction:: {{ objname }}

.. raw:: html

    <div style='clear:both'></div>
